﻿namespace Pimc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblpeso = new System.Windows.Forms.Label();
            this.lblaltura = new System.Windows.Forms.Label();
            this.lblimc = new System.Windows.Forms.Label();
            this.mskbxpeso = new System.Windows.Forms.MaskedTextBox();
            this.mskbxaltura = new System.Windows.Forms.MaskedTextBox();
            this.txtimc = new System.Windows.Forms.TextBox();
            this.btncalc = new System.Windows.Forms.Button();
            this.btnlimp = new System.Windows.Forms.Button();
            this.btnsair = new System.Windows.Forms.Button();
            this.txtimcvalor = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblpeso
            // 
            this.lblpeso.AutoSize = true;
            this.lblpeso.Location = new System.Drawing.Point(739, 38);
            this.lblpeso.Name = "lblpeso";
            this.lblpeso.Size = new System.Drawing.Size(72, 16);
            this.lblpeso.TabIndex = 0;
            this.lblpeso.Text = "Peso Atual";
            // 
            // lblaltura
            // 
            this.lblaltura.AutoSize = true;
            this.lblaltura.Location = new System.Drawing.Point(739, 76);
            this.lblaltura.Name = "lblaltura";
            this.lblaltura.Size = new System.Drawing.Size(41, 16);
            this.lblaltura.TabIndex = 1;
            this.lblaltura.Text = "Altura";
            // 
            // lblimc
            // 
            this.lblimc.AutoSize = true;
            this.lblimc.Location = new System.Drawing.Point(739, 114);
            this.lblimc.Name = "lblimc";
            this.lblimc.Size = new System.Drawing.Size(30, 16);
            this.lblimc.TabIndex = 2;
            this.lblimc.Text = "IMC";
            // 
            // mskbxpeso
            // 
            this.mskbxpeso.Location = new System.Drawing.Point(855, 32);
            this.mskbxpeso.Mask = "099.99 ";
            this.mskbxpeso.Name = "mskbxpeso";
            this.mskbxpeso.Size = new System.Drawing.Size(162, 22);
            this.mskbxpeso.TabIndex = 3;
            this.mskbxpeso.Validated += new System.EventHandler(this.mskbxpeso_Validated);
            // 
            // mskbxaltura
            // 
            this.mskbxaltura.Location = new System.Drawing.Point(855, 73);
            this.mskbxaltura.Mask = "0.00 ";
            this.mskbxaltura.Name = "mskbxaltura";
            this.mskbxaltura.Size = new System.Drawing.Size(162, 22);
            this.mskbxaltura.TabIndex = 4;
            this.mskbxaltura.Validated += new System.EventHandler(this.mskbxaltura_Validated);
            // 
            // txtimc
            // 
            this.txtimc.Enabled = false;
            this.txtimc.Location = new System.Drawing.Point(855, 114);
            this.txtimc.Name = "txtimc";
            this.txtimc.Size = new System.Drawing.Size(162, 22);
            this.txtimc.TabIndex = 5;
            // 
            // btncalc
            // 
            this.btncalc.Location = new System.Drawing.Point(742, 177);
            this.btncalc.Name = "btncalc";
            this.btncalc.Size = new System.Drawing.Size(75, 54);
            this.btncalc.TabIndex = 6;
            this.btncalc.Text = "Calcular";
            this.btncalc.UseVisualStyleBackColor = true;
            this.btncalc.Click += new System.EventHandler(this.btncalc_Click);
            // 
            // btnlimp
            // 
            this.btnlimp.Location = new System.Drawing.Point(855, 177);
            this.btnlimp.Name = "btnlimp";
            this.btnlimp.Size = new System.Drawing.Size(75, 54);
            this.btnlimp.TabIndex = 7;
            this.btnlimp.Text = "Limpar";
            this.btnlimp.UseVisualStyleBackColor = true;
            this.btnlimp.Click += new System.EventHandler(this.btnlimp_Click);
            // 
            // btnsair
            // 
            this.btnsair.Location = new System.Drawing.Point(967, 176);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(75, 55);
            this.btnsair.TabIndex = 8;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = true;
            // 
            // txtimcvalor
            // 
            this.txtimcvalor.Enabled = false;
            this.txtimcvalor.Location = new System.Drawing.Point(1054, 113);
            this.txtimcvalor.Name = "txtimcvalor";
            this.txtimcvalor.Size = new System.Drawing.Size(100, 22);
            this.txtimcvalor.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1371, 641);
            this.Controls.Add(this.txtimcvalor);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.btnlimp);
            this.Controls.Add(this.btncalc);
            this.Controls.Add(this.txtimc);
            this.Controls.Add(this.mskbxaltura);
            this.Controls.Add(this.mskbxpeso);
            this.Controls.Add(this.lblimc);
            this.Controls.Add(this.lblaltura);
            this.Controls.Add(this.lblpeso);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpeso;
        private System.Windows.Forms.Label lblaltura;
        private System.Windows.Forms.Label lblimc;
        private System.Windows.Forms.MaskedTextBox mskbxpeso;
        private System.Windows.Forms.MaskedTextBox mskbxaltura;
        private System.Windows.Forms.TextBox txtimc;
        private System.Windows.Forms.Button btncalc;
        private System.Windows.Forms.Button btnlimp;
        private System.Windows.Forms.Button btnsair;
        private System.Windows.Forms.TextBox txtimcvalor;
    }
}

