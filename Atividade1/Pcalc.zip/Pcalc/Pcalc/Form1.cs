﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;




namespace Pcalc
{
    public partial class Form1 : Form
    {
        double num1;
        double num2;
        double Resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtnumero1_TextChanged(object sender, EventArgs e)
        {
            if(this.ActiveControl==btnsair)
            {
                return;
            }

            if(!double.TryParse(txtnumero1.Text,out num1))
                {
                MessageBox.Show("numero Invalido");
                txtnumero1.Focus();                   
            }
        }

        private void txtnumero2_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnsair)
            {
                return;
            }

            if (!double.TryParse(txtnumero2.Text,out num2))
                {
                MessageBox.Show("numero Invalido");
                txtnumero2.Focus();
            }
        }

        private void btnsoma_Click(object sender, EventArgs e)
        {
            Resultado = num1 + num2;
            txtresultado.Text = Resultado.ToString("N2");
        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            Resultado = num1 - num2;
            txtresultado.Text = Resultado.ToString("N2");
        }

        private void btnmult_Click(object sender, EventArgs e)
        {
            Resultado = num1 * num2;
            txtresultado.Text = Resultado.ToString("N2");
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            if (num2 == 0)
            {
                MessageBox.Show("Divisão invalida");
                txtnumero2.Focus();
            }
            else
            {
                Resultado = num1 / num2;
                txtresultado.Text = Resultado.ToString("N2");
            }
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtnumero1.Clear();
            txtnumero2.Clear();
            txtresultado.Clear();
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
