﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbllado1 = new System.Windows.Forms.Label();
            this.lbllado2 = new System.Windows.Forms.Label();
            this.lbllado3 = new System.Windows.Forms.Label();
            this.txtlado1 = new System.Windows.Forms.TextBox();
            this.txtlado2 = new System.Windows.Forms.TextBox();
            this.txtlado3 = new System.Windows.Forms.TextBox();
            this.pctimagem = new System.Windows.Forms.PictureBox();
            this.btncalcular = new System.Windows.Forms.Button();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.btnsair = new System.Windows.Forms.Button();
            this.errora = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorB = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorC = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pctimagem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errora)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorC)).BeginInit();
            this.SuspendLayout();
            // 
            // lbllado1
            // 
            this.lbllado1.AutoSize = true;
            this.lbllado1.Location = new System.Drawing.Point(82, 74);
            this.lbllado1.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lbllado1.Name = "lbllado1";
            this.lbllado1.Size = new System.Drawing.Size(117, 37);
            this.lbllado1.TabIndex = 0;
            this.lbllado1.Text = "Lado 1";
            // 
            // lbllado2
            // 
            this.lbllado2.AutoSize = true;
            this.lbllado2.Location = new System.Drawing.Point(82, 172);
            this.lbllado2.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lbllado2.Name = "lbllado2";
            this.lbllado2.Size = new System.Drawing.Size(120, 37);
            this.lbllado2.TabIndex = 1;
            this.lbllado2.Text = "Lado 2";
            // 
            // lbllado3
            // 
            this.lbllado3.AutoSize = true;
            this.lbllado3.Location = new System.Drawing.Point(82, 269);
            this.lbllado3.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lbllado3.Name = "lbllado3";
            this.lbllado3.Size = new System.Drawing.Size(119, 37);
            this.lbllado3.TabIndex = 2;
            this.lbllado3.Text = "Lado 3";
            // 
            // txtlado1
            // 
            this.txtlado1.Location = new System.Drawing.Point(318, 74);
            this.txtlado1.Margin = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.txtlado1.Name = "txtlado1";
            this.txtlado1.Size = new System.Drawing.Size(268, 43);
            this.txtlado1.TabIndex = 3;
            this.txtlado1.Validated += new System.EventHandler(this.txtlado1_Validated);
            // 
            // txtlado2
            // 
            this.txtlado2.Location = new System.Drawing.Point(318, 172);
            this.txtlado2.Margin = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.txtlado2.Name = "txtlado2";
            this.txtlado2.Size = new System.Drawing.Size(268, 43);
            this.txtlado2.TabIndex = 4;
            this.txtlado2.Validated += new System.EventHandler(this.txtlado2_Validated);
            // 
            // txtlado3
            // 
            this.txtlado3.Location = new System.Drawing.Point(318, 269);
            this.txtlado3.Margin = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.txtlado3.Name = "txtlado3";
            this.txtlado3.Size = new System.Drawing.Size(268, 43);
            this.txtlado3.TabIndex = 5;
            this.txtlado3.Validated += new System.EventHandler(this.txtlado3_Validated);
            // 
            // pctimagem
            // 
            this.pctimagem.Image = global::Ptriangulo.Properties.Resources.images__1_;
            this.pctimagem.Location = new System.Drawing.Point(715, 132);
            this.pctimagem.Margin = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.pctimagem.Name = "pctimagem";
            this.pctimagem.Size = new System.Drawing.Size(418, 112);
            this.pctimagem.TabIndex = 6;
            this.pctimagem.TabStop = false;
            // 
            // btncalcular
            // 
            this.btncalcular.BackColor = System.Drawing.Color.Blue;
            this.btncalcular.Location = new System.Drawing.Point(90, 398);
            this.btncalcular.Margin = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.btncalcular.Name = "btncalcular";
            this.btncalcular.Size = new System.Drawing.Size(296, 169);
            this.btncalcular.TabIndex = 7;
            this.btncalcular.Text = "Calcular";
            this.btncalcular.UseVisualStyleBackColor = false;
            this.btncalcular.Click += new System.EventHandler(this.btncalcular_Click);
            // 
            // btnlimpar
            // 
            this.btnlimpar.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnlimpar.Location = new System.Drawing.Point(494, 398);
            this.btnlimpar.Margin = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(292, 169);
            this.btnlimpar.TabIndex = 8;
            this.btnlimpar.Text = "Limpar";
            this.btnlimpar.UseVisualStyleBackColor = false;
            this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
            // 
            // btnsair
            // 
            this.btnsair.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnsair.Location = new System.Drawing.Point(878, 398);
            this.btnsair.Margin = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(280, 169);
            this.btnsair.TabIndex = 9;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = false;
            this.btnsair.Click += new System.EventHandler(this.btnsair_Click);
            // 
            // errora
            // 
            this.errora.ContainerControl = this;
            // 
            // errorB
            // 
            this.errorB.ContainerControl = this;
            // 
            // errorC
            // 
            this.errorC.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(22F, 36F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkViolet;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1924, 1175);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.btncalcular);
            this.Controls.Add(this.pctimagem);
            this.Controls.Add(this.txtlado3);
            this.Controls.Add(this.txtlado2);
            this.Controls.Add(this.txtlado1);
            this.Controls.Add(this.lbllado3);
            this.Controls.Add(this.lbllado2);
            this.Controls.Add(this.lbllado1);
            this.Font = new System.Drawing.Font("Matura MT Script Capitals", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.Margin = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pctimagem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errora)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorC)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbllado1;
        private System.Windows.Forms.Label lbllado2;
        private System.Windows.Forms.Label lbllado3;
        private System.Windows.Forms.TextBox txtlado1;
        private System.Windows.Forms.TextBox txtlado2;
        private System.Windows.Forms.TextBox txtlado3;
        private System.Windows.Forms.PictureBox pctimagem;
        private System.Windows.Forms.Button btncalcular;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button btnsair;
        private System.Windows.Forms.ErrorProvider errora;
        private System.Windows.Forms.ErrorProvider errorB;
        private System.Windows.Forms.ErrorProvider errorC;
    }
}

