﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double valorA, valorB, valorC;

        private void txtlado2_Validated(object sender, EventArgs e)
        {
            try
            {
                errora.SetError(txtlado2, "");

                valorB = Convert.ToDouble(txtlado2.Text);
            }
            catch (Exception ex)
            {
                errora.SetError(txtlado2, "Valor do lado B invalido!");
            }
        }

        private void txtlado3_Validated(object sender, EventArgs e)
        {
            try
            {
                errora.SetError(txtlado3, "");

                valorC = Convert.ToDouble(txtlado3.Text);
            }
            catch (Exception ex)
            {
                errora.SetError(txtlado3, "Valor do lado C invalido!");
            }
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            if (((valorA < (valorB + valorC)) && (valorA > (Math.Abs(valorB - valorC)))) &&
                ((valorB < (valorA + valorC)) && (valorB > (Math.Abs(valorA - valorC)))) &&
                 ((valorC < (valorA + valorB)) && (valorC > (Math.Abs(valorA - valorB))))) 
            {
                if
                    (valorA == valorB && valorB == valorC)
                {
                    MessageBox.Show("triangulo Equilátero!");
                }

                // MessageBox.Show($"os valores {valorA}, {valorB},{valorC}")
                else if (valorA == valorB || valorB == valorC || valorA == valorC)
                {
                    MessageBox.Show("Triangulo isóceles!");
                }
                else
                {
                    MessageBox.Show("Triangulo escaleno!");
                }

            }
            else
            {
                MessageBox.Show("Trinagulo invalido!");
            }
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtlado1.Clear();
            txtlado2.Clear();
            txtlado3.Clear();
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtlado1_Validated(object sender, EventArgs e)
        {
            try
            {
                errora.SetError(txtlado1, "");

                valorA = Convert.ToDouble(txtlado1.Text);
            }
            catch (Exception ex)
            {
                errora.SetError(txtlado1, "Valor do lado A invalido!");
            }
        }
    }
}
